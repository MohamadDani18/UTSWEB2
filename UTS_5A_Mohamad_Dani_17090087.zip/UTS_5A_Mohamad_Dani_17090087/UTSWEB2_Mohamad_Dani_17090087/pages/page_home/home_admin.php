<div>
    <ul class="breadcrumb">
        <li>
            <a href="#">Home</a> <span class="divider">/</span>
        </li>
        <li>
            <a href="#">Beranda</a>
        </li>
    </ul>
</div>
<div class="span10">
    <h2>Selamat Datang</h2>
    <div class="tooltip-demo well">
        <p class="muted" style="margin-bottom: 0;">
            Sistem informasi sakrad motor merupakan aplikasi yang dipergunakan untuk mencatat proses jual beli motor bekas honda, suzuki, yamaha dll. <br/>
            Selamat datang dan selamat bekerja.
        </p>
    </div>
</div>